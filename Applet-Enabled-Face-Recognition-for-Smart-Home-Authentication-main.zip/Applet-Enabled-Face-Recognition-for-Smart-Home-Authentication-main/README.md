# Applet-Enabled Face Recognition for Smart Home Authentication
 Applet-Enabled Face Recognition for Smart Home Authentication is a model in which a device will be deployed in the residence alongside an app for the homeowner to manage people and receive notifications.
